package com.interfree.tv

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Night = Color(0xFF080B14)
private val Panel = Color(0xFF121827)
private val Panel2 = Color(0xFF1A2233)
private val Cyan = Color(0xFF22D3EE)
private val Blue = Color(0xFF287BFF)
private val Red = Color(0xFFFF465D)
private val Muted = Color(0xFF9AA8BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 11, 20)
        window.navigationBarColor = android.graphics.Color.rgb(8, 11, 20)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, secondary = Blue, background = Night, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Surface(Modifier.fillMaxSize(), color = Night) { App() }
            }
        }
    }
}

@Composable
private fun AppBackdrop(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFF101B30), Night, Color(0xFF090B12)))
    ), content = content)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var movies by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    var series by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf<Channel?>(null) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    var episodeSeries by remember { mutableStateOf<MediaEntry?>(null) }
    var episodeList by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }

    fun load(mode: Int, a: String, b: String, c: String) {
        loading = true; error = ""
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val live = if (mode == 0) Repo.parseM3u(Repo.http(a)) else Repo.xtream(a, b, c)
                    val vod = if (mode == 1) runCatching { Repo.xtreamMovies(a, b, c) }.getOrDefault(emptyList()) else emptyList()
                    val tvSeries = if (mode == 1) runCatching { Repo.xtreamSeries(a, b, c) }.getOrDefault(emptyList()) else emptyList()
                    Triple(live, vod, tvSeries)
                }
                if (result.first.isEmpty()) error = "La lista no tiene canales" else {
                    channels = result.first; movies = result.second; series = result.third
                    prefs.edit().putInt("mode", mode).putString("a", a).putString("b", b).putString("c", c).apply()
                }
            } catch (e: Exception) { error = "No se pudo cargar: ${e.message}" }
            loading = false
        }
    }

    LaunchedEffect(Unit) {
        if (prefs.contains("a")) load(prefs.getInt("mode", 0), prefs.getString("a", "")!!,
            prefs.getString("b", "")!!, prefs.getString("c", "")!!)
    }

    val current = playing
    when {
        current != null -> PlayerScreen(current) { playing = null }
        channels.isEmpty() -> LoginScreen(loading, error, prefs) { m, a, b, c -> load(m, a, b, c) }
        else -> BrowseScreen(channels, movies, series, favs, prefs.getInt("mode", 0) == 1,
            onPlayChannel = { playing = it }, onPlayMedia = { media ->
                playing = Channel(media.id, media.name, media.category, media.url, media.image)
            }, onToggleFav = { url ->
                favs = if (url in favs) favs - url else favs + url
                prefs.edit().putStringSet("favs", favs).apply()
            }, onLoadEpisodes = { item ->
                scope.launch {
                    val eps = withContext(Dispatchers.IO) { runCatching {
                        Repo.seriesEpisodes(prefs.getString("a", "")!!, prefs.getString("b", "")!!, prefs.getString("c", "")!!, item.id)
                    }.getOrDefault(emptyList()) }
                    episodeSeries = item
                    episodeList = eps
                }
            }, onLogout = { channels = emptyList(); movies = emptyList(); series = emptyList(); prefs.edit().remove("a").apply() },
            episodeSeries = episodeSeries, episodes = episodeList, onCloseEpisodes = { episodeSeries = null },
            onPlayEpisode = { playing = Channel(it.id, it.name, it.category, it.url, it.image); episodeSeries = null })
    }
}

@Composable
fun LoginScreen(loading: Boolean, error: String, prefs: SharedPreferences,
                onGo: (Int, String, String, String) -> Unit) {
    val savedMode = prefs.getInt("mode", 0)
    var tab by remember { mutableIntStateOf(savedMode) }
    var url by remember { mutableStateOf(if (savedMode == 0) prefs.getString("a", "")!! else "") }
    var server by remember { mutableStateOf(if (savedMode == 1) prefs.getString("a", "")!! else "") }
    var user by remember { mutableStateOf(prefs.getString("b", "")!!) }
    var pass by remember { mutableStateOf(prefs.getString("c", "")!!) }

    AppBackdrop {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Spacer(Modifier.height(28.dp))
            Image(painterResource(R.drawable.interfree_logo_full), "INTERFREE TV",
                Modifier.fillMaxWidth().heightIn(max = 180.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.height(10.dp))
            Text("TU ENTRETENIMIENTO, EN UN SOLO LUGAR", color = Cyan, fontSize = 11.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(24.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF1A263A), Panel)))
                .border(1.dp, Color(0xFF2B405C), RoundedCornerShape(26.dp)).padding(20.dp)) {
                Text("Conecta tu televisión", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(5.dp))
                Text("Agrega tus datos de acceso para comenzar", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                TabRow(selectedTabIndex = tab, containerColor = Color(0xFF0C1320),
                    contentColor = Cyan) {
                    Tab(tab == 0, { tab = 0 }, text = { Text("LISTA M3U", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
                    Tab(tab == 1, { tab = 1 }, text = { Text("XTREAM", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
                }
                Spacer(Modifier.height(16.dp))
                if (tab == 0) {
                    StyledField(url, { url = it }, "URL de la lista M3U", keyboard = KeyboardType.Uri)
                } else {
                    StyledField(server, { server = it }, "Servidor (http://host:puerto)", keyboard = KeyboardType.Uri)
                    Spacer(Modifier.height(10.dp))
                    StyledField(user, { user = it }, "Usuario")
                    Spacer(Modifier.height(10.dp))
                    StyledField(pass, { pass = it }, "Contraseña", secret = true)
                }
                if (error.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(error, color = Color(0xFFFF7185), fontSize = 12.sp)
                }
                Spacer(Modifier.height(18.dp))
                Button(onClick = {
                    if (tab == 0) onGo(0, url.trim(), "", "") else onGo(1, server.trim(), user.trim(), pass.trim())
                }, enabled = !loading, modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF087FAD), disabledContainerColor = Panel2)) {
                    Text(if (loading) "CONECTANDO…" else "CONECTAR Y ENTRAR", fontWeight = FontWeight.Bold, letterSpacing = .6.sp)
                }
                Spacer(Modifier.height(12.dp))
                Text("Compatible con listas M3U y servidores Xtream", color = Muted,
                    fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
            Spacer(Modifier.height(26.dp))
        }
    }
}

@Composable
private fun StyledField(value: String, onValue: (String) -> Unit, label: String,
                        secret: Boolean = false, keyboard: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(value, onValue, label = { Text(label, color = Muted, fontSize = 12.sp) },
        modifier = Modifier.fillMaxWidth(), singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF34445D),
            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            cursorColor = Cyan, focusedContainerColor = Color(0xFF0B1220),
            unfocusedContainerColor = Color(0xFF0B1220)))
}

@Composable
fun BrowseScreen(
    channels: List<Channel>, movies: List<MediaEntry>, series: List<MediaEntry>, favs: Set<String>, hasXtream: Boolean,
    onPlayChannel: (Channel) -> Unit, onPlayMedia: (MediaEntry) -> Unit, onToggleFav: (String) -> Unit,
    onLoadEpisodes: (MediaEntry) -> Unit, onLogout: () -> Unit,
    episodeSeries: MediaEntry?, episodes: List<MediaEntry>, onCloseEpisodes: () -> Unit, onPlayEpisode: (MediaEntry) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todos") }
    val categories = when (tab) {
        0 -> listOf("Todos", "Favoritos") + channels.map { it.group }.distinct()
        1 -> listOf("Todos") + movies.map { it.category }.distinct()
        else -> listOf("Todos") + series.map { it.category }.distinct()
    }
    val filteredChannels = channels.filter { (category == "Todos" || (category == "Favoritos" && it.url in favs) || it.group == category) && it.name.contains(query, true) }
    val media = if (tab == 1) movies else series
    val filteredMedia = media.filter { (category == "Todos" || it.category == category) && it.name.contains(query, true) }
    AppBackdrop {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 14.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 7.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.interfree_logo_horizontal), "INTERFREE TV", Modifier.width(155.dp).height(48.dp), contentScale = ContentScale.Fit)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onLogout) { Text("Salir", color = Cyan) }
            }
            TabRow(selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = Cyan) {
                listOf("En vivo", "Películas", "Series").forEachIndexed { index, label ->
                    Tab(selected = tab == index, onClick = { tab = index; category = "Todos"; query = "" }, text = {
                        Text(label, fontWeight = if (tab == index) FontWeight.Bold else FontWeight.Normal)
                    })
                }
            }
            if (!hasXtream && tab != 0) {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Contenido VOD disponible con Xtream Codes", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp)); Text("Tu lista M3U puede mostrar canales en vivo, pero no entrega un catálogo estándar de películas y series.", color = Muted, fontSize = 13.sp)
                }
            } else {
                OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    placeholder = { Text(if (tab == 0) "Buscar canal…" else "Buscar título…", color = Muted) }, singleLine = true,
                    shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan,
                        unfocusedBorderColor = Color(0xFF2C3B52), focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        cursorColor = Cyan, focusedContainerColor = Panel, unfocusedContainerColor = Panel))
                LazyRow(Modifier.padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(categories) { item -> FilterChip(selected = category == item, onClick = { category = item },
                        label = { Text(item, fontSize = 11.sp, maxLines = 1) }, shape = RoundedCornerShape(30.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF075C7B), selectedLabelColor = Color.White,
                            containerColor = Panel, labelColor = Muted)) }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(when (tab) { 0 -> "CANALES EN VIVO"; 1 -> "CATÁLOGO DE PELÍCULAS"; else -> "CATÁLOGO DE SERIES" }, color = Cyan,
                        fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(Modifier.weight(1f)); Text("${if (tab == 0) filteredChannels.size else filteredMedia.size} títulos", color = Muted, fontSize = 11.sp)
                }
                if (tab == 0) {
                    LazyColumn(contentPadding = PaddingValues(bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(filteredChannels) { ch ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel)
                                .border(1.dp, Color(0xFF25334A), RoundedCornerShape(15.dp)).clickable { onPlayChannel(ch) }.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                LogoImage(ch.logo, Modifier.size(54.dp))
                                Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) {
                                    Text(ch.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                                    Text(ch.group, color = Muted, fontSize = 11.sp, maxLines = 1)
                                }
                                TextButton(onClick = { onToggleFav(ch.url) }) { Text(if (ch.url in favs) "★" else "☆", color = if (ch.url in favs) Color(0xFFFFC857) else Muted, fontSize = 22.sp) }
                            }
                        }
                    }
                } else {
                    if (filteredMedia.isEmpty()) {
                        Column(Modifier.fillMaxWidth().padding(top = 46.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (tab == 1) "No se encontraron películas" else "No se encontraron series", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(7.dp))
                            Text("El servidor no devolvió este catálogo o no hay títulos en esta categoría.", color = Muted, fontSize = 12.sp)
                        }
                    } else LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 22.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        gridItems(filteredMedia) { item ->
                            Column(Modifier.fillMaxWidth().clickable { if (item.isSeries) onLoadEpisodes(item) else onPlayMedia(item) }) {
                                AsyncImage(model = item.image.takeIf { it.isNotBlank() }, contentDescription = item.name,
                                    modifier = Modifier.fillMaxWidth().height(158.dp).clip(RoundedCornerShape(12.dp)).background(Panel2),
                                    contentScale = ContentScale.Crop)
                                Spacer(Modifier.height(6.dp))
                                Text(item.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                                Text(item.year.ifBlank { item.category }, color = Muted, fontSize = 10.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        if (episodeSeries != null) {
            AlertDialog(onDismissRequest = onCloseEpisodes, containerColor = Panel,
                title = { Text(episodeSeries.name, color = Color.White) },
                text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    if (episodes.isEmpty()) Text("No se pudieron obtener los episodios de esta serie.", color = Muted)
                    episodes.forEach { ep ->
                        TextButton(onClick = { onPlayEpisode(ep) }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth()) { Text(ep.name, color = Color.White); Text(ep.category, color = Muted, fontSize = 11.sp) }
                        }
                    }
                } }, confirmButton = { TextButton(onClick = onCloseEpisodes) { Text("Cerrar", color = Cyan) } })
        }
    }
}

@Composable
private fun LogoImage(url: String, modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Color(0xFF16405A), Color(0xFF202C48)))),
        contentAlignment = Alignment.Center) {
        if (url.isNotBlank()) AsyncImage(model = url, contentDescription = "Logo del canal", modifier = Modifier.fillMaxSize().padding(4.dp), contentScale = ContentScale.Fit)
        else Text("▶", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PlayerScreen(ch: Channel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(ch.url)); prepare(); playWhenReady = true }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    BackHandler(onBack = onBack)
    AndroidView(factory = { c -> PlayerView(c).apply { this.player = player; keepScreenOn = true } }, modifier = Modifier.fillMaxSize())
}
