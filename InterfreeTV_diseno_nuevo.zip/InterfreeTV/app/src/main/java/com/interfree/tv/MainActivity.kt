package com.interfree.tv

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Night = Color(0xFF080B14)
private val Panel = Color(0xFF121827)
private val Panel2 = Color(0xFF1A2233)
private val Cyan = Color(0xFF22D3EE)
private val Blue = Color(0xFF287BFF)
private val Red = Color(0xFFFF465D)
private val Muted = Color(0xFF9AA8BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 11, 20)
        window.navigationBarColor = android.graphics.Color.rgb(8, 11, 20)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, secondary = Blue, background = Night, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Surface(Modifier.fillMaxSize(), color = Night) { App() }
            }
        }
    }
}

@Composable
private fun AppBackdrop(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFF101B30), Night, Color(0xFF090B12)))
    ), content = content)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf<Channel?>(null) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }

    fun load(mode: Int, a: String, b: String, c: String) {
        loading = true; error = ""
        scope.launch {
            try {
                val list = withContext(Dispatchers.IO) {
                    if (mode == 0) Repo.parseM3u(Repo.http(a)) else Repo.xtream(a, b, c)
                }
                if (list.isEmpty()) error = "La lista no tiene canales" else {
                    channels = list
                    prefs.edit().putInt("mode", mode).putString("a", a).putString("b", b).putString("c", c).apply()
                }
            } catch (e: Exception) { error = "No se pudo cargar: ${e.message}" }
            loading = false
        }
    }

    LaunchedEffect(Unit) {
        if (prefs.contains("a")) load(prefs.getInt("mode", 0), prefs.getString("a", "")!!,
            prefs.getString("b", "")!!, prefs.getString("c", "")!!)
    }

    val current = playing
    when {
        current != null -> PlayerScreen(current) { playing = null }
        channels.isEmpty() -> LoginScreen(loading, error, prefs) { m, a, b, c -> load(m, a, b, c) }
        else -> ChannelsScreen(channels, favs, { playing = it }, { url ->
            favs = if (url in favs) favs - url else favs + url
            prefs.edit().putStringSet("favs", favs).apply()
        }, {
            channels = emptyList(); prefs.edit().remove("a").apply()
        })
    }
}

@Composable
fun LoginScreen(loading: Boolean, error: String, prefs: SharedPreferences,
                onGo: (Int, String, String, String) -> Unit) {
    val savedMode = prefs.getInt("mode", 0)
    var tab by remember { mutableIntStateOf(savedMode) }
    var url by remember { mutableStateOf(if (savedMode == 0) prefs.getString("a", "")!! else "") }
    var server by remember { mutableStateOf(if (savedMode == 1) prefs.getString("a", "")!! else "") }
    var user by remember { mutableStateOf(prefs.getString("b", "")!!) }
    var pass by remember { mutableStateOf(prefs.getString("c", "")!!) }

    AppBackdrop {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Spacer(Modifier.height(28.dp))
            Image(painterResource(R.drawable.interfree_logo_full), "INTERFREE TV",
                Modifier.fillMaxWidth().heightIn(max = 180.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.height(10.dp))
            Text("TU ENTRETENIMIENTO, EN UN SOLO LUGAR", color = Cyan, fontSize = 11.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(24.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF1A263A), Panel)))
                .border(1.dp, Color(0xFF2B405C), RoundedCornerShape(26.dp)).padding(20.dp)) {
                Text("Conecta tu televisión", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(5.dp))
                Text("Agrega tus datos de acceso para comenzar", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                TabRow(selectedTabIndex = tab, containerColor = Color(0xFF0C1320),
                    contentColor = Cyan) {
                    Tab(tab == 0, { tab = 0 }, text = { Text("LISTA M3U", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
                    Tab(tab == 1, { tab = 1 }, text = { Text("XTREAM", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
                }
                Spacer(Modifier.height(16.dp))
                if (tab == 0) {
                    StyledField(url, { url = it }, "URL de la lista M3U", keyboard = KeyboardType.Uri)
                } else {
                    StyledField(server, { server = it }, "Servidor (http://host:puerto)", keyboard = KeyboardType.Uri)
                    Spacer(Modifier.height(10.dp))
                    StyledField(user, { user = it }, "Usuario")
                    Spacer(Modifier.height(10.dp))
                    StyledField(pass, { pass = it }, "Contraseña", secret = true)
                }
                if (error.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(error, color = Color(0xFFFF7185), fontSize = 12.sp)
                }
                Spacer(Modifier.height(18.dp))
                Button(onClick = {
                    if (tab == 0) onGo(0, url.trim(), "", "") else onGo(1, server.trim(), user.trim(), pass.trim())
                }, enabled = !loading, modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF087FAD), disabledContainerColor = Panel2)) {
                    Text(if (loading) "CONECTANDO…" else "CONECTAR Y ENTRAR", fontWeight = FontWeight.Bold, letterSpacing = .6.sp)
                }
                Spacer(Modifier.height(12.dp))
                Text("Compatible con listas M3U y servidores Xtream", color = Muted,
                    fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
            Spacer(Modifier.height(26.dp))
        }
    }
}

@Composable
private fun StyledField(value: String, onValue: (String) -> Unit, label: String,
                        secret: Boolean = false, keyboard: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(value, onValue, label = { Text(label, color = Muted, fontSize = 12.sp) },
        modifier = Modifier.fillMaxWidth(), singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF34445D),
            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            cursorColor = Cyan, focusedContainerColor = Color(0xFF0B1220),
            unfocusedContainerColor = Color(0xFF0B1220)))
}

@Composable
fun ChannelsScreen(all: List<Channel>, favs: Set<String>, onPlay: (Channel) -> Unit,
                   onFav: (String) -> Unit, onLogout: () -> Unit) {
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("Todos") }
    val groups = remember(all) { listOf("Todos", "Favoritos") + all.map { it.group }.distinct() }
    val shown = remember(all, favs, q, cat) {
        all.filter { (cat == "Todos" || (cat == "Favoritos" && it.url in favs) || it.group == cat) && it.name.contains(q, true) }
    }
    AppBackdrop {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.interfree_logo_horizontal), "INTERFREE TV",
                    Modifier.width(142.dp).height(48.dp), contentScale = ContentScale.Fit)
                Spacer(Modifier.weight(1f))
                Surface(color = Color(0xFF123B48), shape = RoundedCornerShape(50)) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(Color(0xFF39E6A0), CircleShape))
                        Spacer(Modifier.width(6.dp)); Text("EN VIVO", color = Color(0xFF8CF2D0), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                TextButton(onClick = onLogout) { Text("Salir", color = Muted) }
            }
            Text("Canales de televisión", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Explora tu programación", fontSize = 12.sp, color = Muted)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(q, { q = it }, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar canal…", color = Muted) }, singleLine = true,
                shape = RoundedCornerShape(15.dp), colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF2C3B52),
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    cursorColor = Cyan, focusedContainerColor = Panel, unfocusedContainerColor = Panel))
            Spacer(Modifier.height(12.dp))
            LazyRow(contentPadding = PaddingValues(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(groups) { g ->
                    FilterChip(selected = cat == g, onClick = { cat = g },
                        label = { Text(g, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                        shape = RoundedCornerShape(50), colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF075C7B), selectedLabelColor = Color.White,
                            containerColor = Panel, labelColor = Muted))
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (cat == "Todos") "TODOS LOS CANALES" else cat.uppercase(), color = Cyan,
                    fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.weight(1f)); Text("${shown.size} canales", color = Muted, fontSize = 11.sp)
            }
            LazyColumn(contentPadding = PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown) { ch ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(Panel).border(1.dp, Color(0xFF202D42), RoundedCornerShape(16.dp))
                        .clickable { onPlay(ch) }.padding(horizontal = 13.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF124D69), Color(0xFF202C48)))),
                            contentAlignment = Alignment.Center) {
                            Text("▶", color = Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(ch.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                            Text(ch.group, color = Muted, fontSize = 11.sp, maxLines = 1)
                        }
                        TextButton(onClick = { onFav(ch.url) }) {
                            Text(if (ch.url in favs) "★" else "☆", color = if (ch.url in favs) Color(0xFFFFC857) else Muted, fontSize = 21.sp)
                        }
                        Text("›", color = Muted, fontSize = 25.sp)
                    }
                }
                if (shown.isEmpty()) item {
                    Text("No encontramos canales con ese criterio.", color = Muted, modifier = Modifier.padding(20.dp))
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(ch: Channel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(ch.url)); prepare(); playWhenReady = true }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    BackHandler(onBack = onBack)
    AndroidView(factory = { c -> PlayerView(c).apply { this.player = player; keepScreenOn = true } }, modifier = Modifier.fillMaxSize())
}
