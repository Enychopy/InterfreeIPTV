package com.interfree.tv

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Channel(
    val id: String,
    val name: String,
    val group: String,
    val url: String,
    val logo: String
)

object Repo {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "InterfreeTV/1.0")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Lee una lista M3U / M3U8 con #EXTINF. */
    fun parseM3u(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        val attr = Regex("([\\w-]+)=\"([^\"]*)\"")
        var name = ""
        var group = "Sin categoría"
        var logo = ""
        var id = ""
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF")) {
                val a = attr.findAll(line).associate { it.groupValues[1] to it.groupValues[2] }
                group = a["group-title"]?.takeIf { it.isNotBlank() } ?: "Sin categoría"
                logo = a["tvg-logo"] ?: ""
                id = a["tvg-id"] ?: ""
                name = line.substringAfterLast(",").trim().ifBlank { a["tvg-name"] ?: "" }
            } else if (line.isNotEmpty() && !line.startsWith("#")) {
                out.add(
                    Channel(
                        id.ifBlank { out.size.toString() },
                        name.ifBlank { "Canal ${out.size + 1}" },
                        group, line, logo
                    )
                )
                name = ""; group = "Sin categoría"; logo = ""; id = ""
            }
        }
        return out
    }

    /** Lee canales en vivo de un servidor Xtream Codes. */
    fun xtream(server: String, user: String, pass: String): List<Channel> {
        val base = server.trim().trimEnd('/')
        val auth = "username=${enc(user)}&password=${enc(pass)}"
        val cats = JSONArray(http("$base/player_api.php?$auth&action=get_live_categories"))
        val names = HashMap<String, String>()
        for (i in 0 until cats.length()) {
            val o = cats.getJSONObject(i)
            names[o.optString("category_id")] = o.optString("category_name")
        }
        val arr = JSONArray(http("$base/player_api.php?$auth&action=get_live_streams"))
        val out = ArrayList<Channel>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val sid = o.optString("stream_id")
            out.add(
                Channel(
                    sid,
                    o.optString("name"),
                    names[o.optString("category_id")] ?: "Otros",
                    "$base/live/${enc(user)}/${enc(pass)}/$sid.m3u8",
                    o.optString("stream_icon")
                )
            )
        }
        return out
    }
}
