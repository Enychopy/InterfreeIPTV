package com.interfree.tv

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = BrandColors) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

data class Session(val base: String, val user: String, val pass: String, val account: Account)

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var session by remember { mutableStateOf<Session?>(null) }
    var loginBusy by remember { mutableStateOf(false) }
    var loginError by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var data by remember { mutableStateOf<Map<Int, List<Item>>>(emptyMap()) }
    var error by remember { mutableStateOf("") }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    var series by remember { mutableStateOf<Item?>(null) }
    var episodes by remember { mutableStateOf<List<Episode>?>(null) }
    var playing by remember { mutableStateOf<Pair<String, String>?>(null) }

    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1400)
        splash = false
    }

    fun login(server: String, user: String, pass: String) {
        loginBusy = true
        loginError = ""
        scope.launch {
            try {
                val b = Xt.base(server)
                val acc = withContext(Dispatchers.IO) { Xt.login(b, user, pass) }
                prefs.edit().putString("server", server).putString("user", user)
                    .putString("pass", pass).apply()
                session = Session(b, user, pass, acc)
            } catch (e: Exception) {
                loginError = "No se pudo entrar: ${e.message}"
            }
            loginBusy = false
        }
    }

    LaunchedEffect(Unit) {
        val u = prefs.getString("user", "") ?: ""
        if (u.isNotEmpty()) {
            login(
                if (SERVER_URL.isNotBlank()) SERVER_URL else prefs.getString("server", "")!!,
                u, prefs.getString("pass", "")!!
            )
        }
    }

    LaunchedEffect(session, tab) {
        val s = session ?: return@LaunchedEffect
        if (data[tab] == null) {
            error = ""
            try {
                val list = withContext(Dispatchers.IO) { Xt.catalog(s.base, s.user, s.pass, tab) }
                data = data + (tab to list)
            } catch (e: Exception) {
                error = "No se pudo cargar: ${e.message}"
            }
        }
    }

    val cur = playing
    val ser = series
    val s = session
    when {
        splash -> SplashScreen()
        cur != null -> PlayerScreen(cur.second) { playing = null }
        ser != null -> EpisodesScreen(ser.name, episodes, { playing = it.title to it.url }) {
            series = null
            episodes = null
        }
        s == null -> LoginScreen(loginBusy, loginError, prefs) { sv, u, p -> login(sv, u, p) }
        else -> HomeScreen(
            account = s.account,
            tab = tab,
            onTab = { tab = it },
            items = data[tab],
            error = error,
            favs = favs,
            onOpen = { item ->
                if (item.seriesId.isNotBlank()) {
                    series = item
                    episodes = null
                    scope.launch {
                        episodes = try {
                            withContext(Dispatchers.IO) { Xt.episodes(s.base, s.user, s.pass, item.seriesId) }
                        } catch (e: Exception) { emptyList() }
                    }
                } else {
                    playing = item.name to item.url
                }
            },
            onFav = { key ->
                favs = if (key in favs) favs - key else favs + key
                prefs.edit().putStringSet("favs", favs).apply()
            },
            onLogout = {
                session = null
                data = emptyMap()
                prefs.edit().remove("pass").remove("user").apply()
            }
        )
    }
}

@Composable
fun LoginScreen(busy: Boolean, error: String, prefs: android.content.SharedPreferences, onGo: (String, String, String) -> Unit) {
    var server by remember { mutableStateOf(prefs.getString("server", "")!!) }
    var user by remember { mutableStateOf(prefs.getString("user", "")!!) }
    var pass by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painterResource(R.drawable.logo_full),
            contentDescription = "INTERFREE TV",
            modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp),
            contentScale = ContentScale.Fit
        )
        Text("Inicia sesión con tu usuario")
        Spacer(Modifier.height(16.dp))
        if (SERVER_URL.isBlank()) {
            OutlinedTextField(
                server, { server = it }, label = { Text("Servidor (http://host:puerto)") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
        }
        OutlinedTextField(
            user, { user = it }, label = { Text("Usuario") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            pass, { pass = it }, label = { Text("Contraseña") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        if (error.isNotEmpty()) {
            Text(error, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(8.dp))
        }
        Button(
            onClick = { onGo(if (SERVER_URL.isNotBlank()) SERVER_URL else server.trim(), user.trim(), pass.trim()) },
            enabled = !busy, modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "Entrando…" else "Entrar") }
    }
}

@Composable
fun HomeScreen(
    account: Account,
    tab: Int,
    onTab: (Int) -> Unit,
    items: List<Item>?,
    error: String,
    favs: Set<String>,
    onOpen: (Item) -> Unit,
    onFav: (String) -> Unit,
    onLogout: () -> Unit
) {
    var q by remember(tab) { mutableStateOf("") }
    var cat by remember(tab) { mutableStateOf("Todos") }
    val groups = remember(items) { listOf("Todos", "Favoritos") + (items ?: emptyList()).map { it.group }.distinct() }
    val shown = remember(items, favs, q, cat) {
        (items ?: emptyList()).filter {
            (cat == "Todos" || (cat == "Favoritos" && it.key in favs) || it.group == cat) &&
                it.name.contains(q, ignoreCase = true)
        }
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.logo_mark), contentDescription = null, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.width(8.dp))
                    BrandTitle(22)
                }
                Text(
                    "Vence: ${account.expiry} · Conexiones: ${account.activeCon}/${account.maxCon} · ${account.status}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            TextButton(onClick = onLogout) { Text("Salir") }
        }
        TabRow(selectedTabIndex = tab) {
            listOf("En vivo", "Películas", "Series").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { onTab(i) }, text = { Text(t) })
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            q, { q = it }, placeholder = { Text("Buscar") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        LazyRow {
            items(groups) { g ->
                FilterChip(
                    selected = cat == g, onClick = { cat = g }, label = { Text(g) },
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
        }
        when {
            error.isNotEmpty() -> Text(error, color = MaterialTheme.colorScheme.error)
            items == null -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            else -> LazyColumn {
                items(shown) { it2 ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(it2) }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(it2.name)
                            Text(it2.group, style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { onFav(it2.key) }) {
                            Text(if (it2.key in favs) "★" else "☆")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EpisodesScreen(title: String, eps: List<Episode>?, onPlay: (Episode) -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Volver") }
            Text(title, style = MaterialTheme.typography.titleMedium)
        }
        when {
            eps == null -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            eps.isEmpty() -> Text("No hay episodios disponibles")
            else -> LazyColumn {
                items(eps) { e ->
                    Text(
                        e.title,
                        Modifier.fillMaxWidth().clickable { onPlay(e) }.padding(vertical = 14.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(url: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    BackHandler(onBack = onBack)
    AndroidView(
        factory = { c -> PlayerView(c).apply { this.player = player; keepScreenOn = true } },
        modifier = Modifier.fillMaxSize()
    )
}

val BrandColors = darkColorScheme(
    primary = Color(0xFF2F8CFF),
    onPrimary = Color(0xFF031026),
    secondary = Color(0xFF8B3DFF),
    tertiary = Color(0xFFE5222B),
    background = Color(0xFF030515),
    onBackground = Color(0xFFF2F5FF),
    surface = Color(0xFF030515),
    onSurface = Color(0xFFF2F5FF),
    surfaceVariant = Color(0xFF111A3D),
    onSurfaceVariant = Color(0xFFA9B4D8),
    outline = Color(0xFF2A3566)
)

@Composable
fun BrandTitle(size: Int = 30) {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = Color.White)) { append("INTERFREE ") }
            withStyle(SpanStyle(color = Color(0xFFE5222B))) { append("TV") }
        },
        fontSize = size.sp,
        fontWeight = FontWeight.ExtraBold,
        fontStyle = FontStyle.Italic
    )
}

@Composable
fun SplashScreen() {
    Box(
        Modifier.fillMaxSize().background(Color(0xFF030515)),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painterResource(R.drawable.logo_full),
            contentDescription = "INTERFREE TV",
            modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp),
            contentScale = ContentScale.Fit
        )
    }
}
