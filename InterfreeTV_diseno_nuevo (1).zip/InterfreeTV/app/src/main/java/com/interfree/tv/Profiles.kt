package com.interfree.tv

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

val ProfileColors = listOf(
    Color(0xFF2F8CFF), Color(0xFFE5222B), Color(0xFF8B3DFF),
    Color(0xFF19B5A5), Color(0xFFF59E0B), Color(0xFFEC4899)
)

data class Profile(val id: String, val name: String, val color: Int, val kids: Boolean, val pin: String)

/** Perfiles guardados solo en este dispositivo (SharedPreferences). */
class ProfileStore(private val prefs: SharedPreferences) {
    fun load(): List<Profile> {
        val raw = prefs.getString("profiles", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Profile(o.getString("id"), o.getString("name"), o.optInt("color", 0), o.optBoolean("kids", false), o.optString("pin", ""))
            }
        } catch (_: Exception) { emptyList() }
    }

    fun save(list: List<Profile>) {
        val a = JSONArray()
        list.forEach { p ->
            a.put(JSONObject().put("id", p.id).put("name", p.name).put("color", p.color).put("kids", p.kids).put("pin", p.pin))
        }
        prefs.edit().putString("profiles", a.toString()).apply()
    }

    /** Favoritos del perfil. El primer perfil hereda los favoritos que ya existían antes de los perfiles. */
    fun favs(p: Profile): Set<String> {
        val own = prefs.getStringSet("favs_${p.id}", null)
        if (own != null) return own.toSet()
        return if (load().firstOrNull()?.id == p.id) prefs.getStringSet("favs", emptySet())!!.toSet() else emptySet()
    }
}

private val adultWords = listOf("adult", "xxx", "+18", "18+", "porn", "erotic", "erót", "playboy", "sexo", "sexy")

/** Filtro por palabras clave en categoría y título. No es infalible: depende de cómo nombre el proveedor sus categorías. */
fun kidsSafe(item: Item): Boolean {
    val t = "${item.group} ${item.name}".lowercase()
    return adultWords.none { it in t }
}

@Composable
fun ProfileAvatar(p: Profile, size: Dp) {
    Box(
        Modifier.size(size).background(ProfileColors[p.color.coerceIn(0, ProfileColors.lastIndex)], CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(p.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.45f).sp)
    }
}

@Composable
fun ProfilePickerScreen(profiles: List<Profile>, onChange: (List<Profile>) -> Unit, onPick: (Profile) -> Unit) {
    var manage by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Profile?>(null) }
    var creating by remember { mutableStateOf(profiles.isEmpty()) }
    var pinTarget by remember { mutableStateOf<Pair<Profile, Boolean>?>(null) }

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Color(0xFF0B1030)))).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        BrandTitle(26)
        Spacer(Modifier.height(8.dp))
        Text(
            if (manage) "Administrar perfiles" else "¿Quién está viendo?",
            style = MaterialTheme.typography.headlineSmall, color = Color.White
        )
        Spacer(Modifier.height(20.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(130.dp),
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(profiles, key = { it.id }) { p ->
                val open: () -> Unit = {
                    if (p.pin.isNotEmpty()) pinTarget = p to manage
                    else if (manage) editing = p
                    else onPick(p)
                }
                Column(
                    Modifier.fillMaxWidth().tvFocus(RoundedCornerShape(16.dp)) { open() }.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ProfileAvatar(p, 84.dp)
                    Spacer(Modifier.height(8.dp))
                    Text(p.name, color = Color.White, maxLines = 1, fontWeight = FontWeight.SemiBold)
                    val tag = buildList {
                        if (p.kids) add("Infantil")
                        if (p.pin.isNotEmpty()) add("🔒 PIN")
                    }.joinToString(" · ")
                    if (tag.isNotEmpty()) Text(tag, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (manage) Text("✎ Editar", style = MaterialTheme.typography.labelSmall, color = Blue)
                }
            }
            if (profiles.size < 5) {
                item {
                    Column(
                        Modifier.fillMaxWidth().tvFocus(RoundedCornerShape(16.dp)) { creating = true }.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(84.dp).background(Color(0xFF171D35), CircleShape), contentAlignment = Alignment.Center) {
                            Text("+", color = Color.White, fontSize = 38.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Nuevo perfil", color = Color.White, maxLines = 1)
                    }
                }
            }
        }
        if (profiles.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            SmallTile(if (manage) "✔  Listo" else "⚙  Administrar perfiles", Modifier.fillMaxWidth(0.7f)) { manage = !manage }
        }
    }

    if (creating || editing != null) {
        ProfileEditorDialog(
            initial = editing,
            canDelete = profiles.size > 1,
            onSave = { saved ->
                onChange(
                    if (profiles.any { it.id == saved.id }) profiles.map { if (it.id == saved.id) saved else it }
                    else profiles + saved
                )
                editing = null
                creating = false
            },
            onDelete = {
                onChange(profiles.filter { it.id != editing?.id })
                editing = null
            },
            onDismiss = { editing = null; creating = false }
        )
    }
    pinTarget?.let { (p, forManage) ->
        PinDialog(
            expected = p.pin,
            onOk = {
                pinTarget = null
                if (forManage) editing = p else onPick(p)
            },
            onCancel = { pinTarget = null }
        )
    }
}

@Composable
fun ProfileEditorDialog(
    initial: Profile?,
    canDelete: Boolean,
    onSave: (Profile) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var color by remember { mutableIntStateOf(initial?.color ?: 0) }
    var kids by remember { mutableStateOf(initial?.kids ?: false) }
    var pin by remember { mutableStateOf(initial?.pin ?: "") }
    val pinOk = pin.isEmpty() || pin.length == 4

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nuevo perfil" else "Editar perfil") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(14) },
                    label = { Text("Nombre") },
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ProfileColors.forEachIndexed { i, c ->
                        Box(
                            Modifier.size(30.dp).tvFocus(CircleShape) { color = i }.background(c, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (i == color) Text("✓", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Perfil infantil", Modifier.weight(1f))
                    Switch(checked = kids, onCheckedChange = { kids = it })
                }
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter(Char::isDigit).take(4) },
                    label = { Text("PIN de 4 dígitos (opcional)") },
                    singleLine = true,
                    isError = !pinOk,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && pinOk,
                onClick = {
                    onSave(Profile(initial?.id ?: UUID.randomUUID().toString(), name.trim(), color, kids, pin))
                }
            ) { Text("Guardar") }
        },
        dismissButton = {
            Row {
                if (canDelete && initial != null) TextButton(onClick = onDelete) { Text("Eliminar", color = Red) }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        }
    )
}

@Composable
fun PinDialog(expected: String, onOk: () -> Unit, onCancel: () -> Unit) {
    var v by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Introduce el PIN") },
        text = {
            OutlinedTextField(
                value = v,
                onValueChange = { v = it.filter(Char::isDigit).take(4); bad = false },
                label = { Text(if (bad) "PIN incorrecto" else "PIN") },
                singleLine = true,
                isError = bad,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                visualTransformation = PasswordVisualTransformation()
            )
        },
        confirmButton = {
            TextButton(onClick = { if (v == expected) onOk() else { bad = true; v = "" } }) { Text("Entrar") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancelar") } }
    )
}
